-- ============================================================
--  COLLEGE OF ENGINEERING AND TECHNOLOGY, AKOLA
--  COMPLETE CHATBOT DATABASE - UPDATED
-- ============================================================

CREATE DATABASE IF NOT EXISTS college_chatbot CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE college_chatbot;

DROP TABLE IF EXISTS chatbot;

CREATE TABLE chatbot (
    id INT AUTO_INCREMENT PRIMARY KEY,
    keyword VARCHAR(255) NOT NULL,
    category VARCHAR(100) NOT NULL,
    reply TEXT NOT NULL,
    reply_hindi TEXT,
    reply_marathi TEXT,
    image VARCHAR(500) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- PRINCIPAL
-- ============================================================
INSERT INTO chatbot (keyword, category, reply, reply_hindi, reply_marathi, image) VALUES
('principal', 'principal',
'<b>🎓 Principal</b><br>
<b>Dr. P.V. Thorat</b><br>
<b>Qualification:</b> Ph.D. in Chemical Engineering, M.Tech<br>
<b>Phone:</b> 9960590202<br>
<b>College:</b> College of Engineering and Technology, Akola<br>
<b>Affiliated to:</b> Sant Gadge Baba Amravati University<br>
<b>Office Hours:</b> Mon-Sat, 10:00 AM – 4:00 PM',

'<b>🎓 प्राचार्य</b><br>
<b>डॉ. पी.व्ही. थोरात</b><br>
<b>योग्यता:</b> पीएच.डी. रासायनिक अभियांत्रिकी, एम.टेक<br>
<b>फोन:</b> 9960590202<br>
<b>कार्यालय समय:</b> सोम-शनि, सुबह 10 – शाम 4',

'<b>🎓 प्राचार्य</b><br>
<b>डॉ. पी.व्ही. थोरात</b><br>
<b>पात्रता:</b> पीएच.डी. रासायनिक अभियांत्रिकी, एम.टेक<br>
<b>फोन:</b> 9960590202<br>
<b>कार्यालय वेळ:</b> सोम-शनि, सकाळी 10 – सायंकाळी 4',

'principle.jpeg');

-- ============================================================
-- COURSES / DEPARTMENTS
-- ============================================================
INSERT INTO chatbot (keyword, category, reply, reply_hindi, reply_marathi, image) VALUES
('course', 'courses',
'<b>📚 Courses Offered - COET Akola</b><br><br>
<b>U.G. Courses:</b><br>
1. B.E. Computer Science & Engineering – 180 seats – 4 Years<br>
2. B.E. Information Technology – 120 seats – 4 Years<br>
3. B.E. Civil Engineering – 60 seats – 4 Years<br>
4. B.E. Mechanical Engineering – 60 seats – 4 Years<br>
5. B.Tech Chemical Engineering – 60 seats – 4 Years<br>
6. B.Arch Architecture – 40 seats – 5 Years<br><br>
<b>P.G. Courses:</b><br>
7. MBA – 60 seats – 2 Years<br>
8. M.E. Computer Science & Engineering – 18 seats – 2 Years<br>
9. M.E. Structural Engineering – 18 seats – 2 Years<br>
10. M.Tech Chemical Engineering – 18 seats – 2 Years<br><br>
<b>Diploma:</b><br>
11. Interior Design (D.Arch) – 40 seats – 3 Years<br><br>
<b>Affiliated to:</b> SGBAU | <b>Approved by:</b> AICTE',

'<b>📚 उपलब्ध कोर्स - COET अकोला</b><br>
<b>यू.जी. कोर्स:</b><br>
1. बी.ई. कंप्यूटर साइंस – 180 सीटें – 4 साल<br>
2. बी.ई. इन्फॉर्मेशन टेक्नोलॉजी – 120 सीटें – 4 साल<br>
3. बी.ई. सिविल – 60 सीटें – 4 साल<br>
4. बी.ई. मैकेनिकल – 60 सीटें – 4 साल<br>
5. बी.टेक केमिकल – 60 सीटें – 4 साल<br>
6. बी.आर्क आर्किटेक्चर – 40 सीटें – 5 साल<br>
<b>पी.जी. कोर्स:</b><br>
7. MBA – 60 सीटें – 2 साल<br>
8. M.E. CSE – 18 सीटें – 2 साल<br>
9. M.E. स्ट्रक्चरल – 18 सीटें – 2 साल<br>
10. M.Tech केमिकल – 18 सीटें – 2 साल<br>
<b>डिप्लोमा:</b> इंटीरियर डिज़ाइन – 40 सीटें – 3 साल',

'<b>📚 उपलब्ध अभ्यासक्रम - COET अकोला</b><br>
<b>यू.जी. अभ्यासक्रम:</b><br>
1. बी.ई. संगणक विज्ञान – 180 जागा – 4 वर्षे<br>
2. बी.ई. माहिती तंत्रज्ञान – 120 जागा – 4 वर्षे<br>
3. बी.ई. स्थापत्य – 60 जागा – 4 वर्षे<br>
4. बी.ई. यांत्रिकी – 60 जागा – 4 वर्षे<br>
5. बी.टेक रासायनिक – 60 जागा – 4 वर्षे<br>
6. बी.आर्क – 40 जागा – 5 वर्षे<br>
<b>पी.जी.:</b> MBA, M.E. CSE, M.E. Structural, M.Tech Chemical<br>
<b>डिप्लोमा:</b> इंटेरियर डिझाईन – 40 जागा – 3 वर्षे',

NULL);

-- ============================================================
-- DEPARTMENTS - CSE
-- ============================================================
INSERT INTO chatbot (keyword, category, reply, reply_hindi, reply_marathi, image) VALUES
('computer', 'departments',
'<b>🖥️ Computer Science & Engineering Department</b><br>
<b>Seats:</b> 180 | <b>Duration:</b> 4 Years<br><br>
<b>Faculty:</b><br>
• Dr. S.L. Satarkar<br>
• Dr. R.S. Jaiswal<br>
• Dr. S.S. Agrawal<br>
• Dr. K.S. Gilda – Associate Professor<br>
• Dr. S.A. Awachar – Associate Professor<br>
• Dr. V.R. Tripathi – Associate Professor<br>
• Dr. S.K. Agrawal – Associate Professor<br>
• Dr. M.K. Deshmukh – Associate Professor<br>
• Dr. M. Mandapati<br>
• Prof. S.A. Bobade – Assistant Professor<br>
• Prof. Mrs. S.S. Dixit – Assistant Professor<br>
• Prof. M.S. Shegokar – Assistant Professor<br>
• Prof. K.P. Barabde – Assistant Professor<br>
• Prof. R.J. Deshmukh – Assistant Professor<br>
• Prof. P.A. Tayade – Assistant Professor<br>
• Prof. J. Balinge',

'<b>🖥️ कंप्यूटर साइंस & इंजीनियरिंग विभाग</b><br>
<b>सीटें:</b> 180 | <b>अवधि:</b> 4 साल<br>
<b>फैकल्टी:</b> Dr. S.L. Satarkar, Dr. R.S. Jaiswal, Dr. S.S. Agrawal, Dr. K.S. Gilda, Dr. S.A. Awachar, Dr. V.R. Tripathi, Prof. S.A. Bobade, Prof. M.S. Shegokar, Prof. K.P. Barabde, Prof. R.J. Deshmukh, Prof. P.A. Tayade एवं अन्य।',

'<b>🖥️ संगणक विज्ञान व अभियांत्रिकी विभाग</b><br>
<b>जागा:</b> 180 | <b>कालावधी:</b> 4 वर्षे<br>
<b>प्राध्यापक:</b> Dr. S.L. Satarkar, Dr. R.S. Jaiswal, Dr. S.S. Agrawal, Dr. K.S. Gilda, Prof. S.A. Bobade, Prof. K.P. Barabde, Prof. P.A. Tayade इतर.',

NULL);

-- ============================================================
-- DEPARTMENTS - IT
-- ============================================================
INSERT INTO chatbot (keyword, category, reply, reply_hindi, reply_marathi, image) VALUES
('information technology', 'departments',
'<b>💻 Information Technology Department</b><br>
<b>Seats:</b> 120 | <b>Duration:</b> 4 Years<br><br>
<b>Faculty:</b><br>
• Dr. R.A. Taley – HOD & Associate Professor<br>
• Mrs. Priyanka P. Mahalle – Assistant Professor<br>
• Prof. Mr. Rahul M. Bhutada – Assistant Professor',

'<b>💻 इन्फॉर्मेशन टेक्नोलॉजी विभाग</b><br>
<b>सीटें:</b> 120 | <b>अवधि:</b> 4 साल<br>
<b>HOD:</b> Dr. R.A. Taley<br>
<b>फैकल्टी:</b> Mrs. Priyanka P. Mahalle, Prof. Rahul M. Bhutada',

'<b>💻 माहिती तंत्रज्ञान विभाग</b><br>
<b>जागा:</b> 120 | <b>कालावधी:</b> 4 वर्षे<br>
<b>HOD:</b> Dr. R.A. Taley<br>
<b>प्राध्यापक:</b> Mrs. Priyanka P. Mahalle, Prof. Rahul M. Bhutada',

NULL);

-- ============================================================
-- DEPARTMENTS - CIVIL
-- ============================================================
INSERT INTO chatbot (keyword, category, reply, reply_hindi, reply_marathi, image) VALUES
('civil', 'departments',
'<b>🏗️ Civil Engineering Department</b><br>
<b>Seats:</b> 60 | <b>Duration:</b> 4 Years<br><br>
<b>Faculty:</b><br>
• Dr. A.R. Gupta – HOD & Professor (M.E, PG in ACM, MBA, Ph.D)<br>
• Dr. A.T. Tathod – Associate Professor (M.E Env Engg., Ph.D)<br>
• Prof. C.S. Kulat – Associate Professor of Practice (M.E Structural)<br>
• Prof. R.M. Phuke – Assistant Professor (M.E Structural)<br>
• Prof. P.M. Raut – Assistant Professor (M.E Env Engg.)<br>
• Prof. G.R. Bharsakle – Assistant Professor (M.E Structural)<br>
• Prof. D.A. Zamre – Assistant Professor (M.E Structural)<br>
• Prof. A.S. Gangane – Assistant Professor (M.E CEM, PGDUPDL)<br>
• Prof. Miss V.N. Wankhade – Assistant Professor (M.Tech Structural)<br>
• Prof. A.S. Kalmegh – Assistant Professor (M.E Environment)<br>
• Prof. S.P. Chore – Assistant Professor (M.E Structure)<br>
• Prof. P.R. Peshwe – Assistant Professor (M.E Structural)<br>
• Prof. P. Mahale',

'<b>🏗️ सिविल इंजीनियरिंग विभाग</b><br>
<b>सीटें:</b> 60 | <b>HOD:</b> Dr. A.R. Gupta<br>
<b>फैकल्टी:</b> Dr. A.T. Tathod, Prof. C.S. Kulat, Prof. R.M. Phuke, Prof. P.M. Raut, Prof. G.R. Bharsakle, Prof. D.A. Zamre, Prof. A.S. Gangane, Prof. V.N. Wankhade, Prof. A.S. Kalmegh, Prof. S.P. Chore, Prof. P.R. Peshwe, Prof. P. Mahale',

'<b>🏗️ स्थापत्य अभियांत्रिकी विभाग</b><br>
<b>जागा:</b> 60 | <b>HOD:</b> Dr. A.R. Gupta<br>
<b>प्राध्यापक:</b> Dr. A.T. Tathod, Prof. C.S. Kulat, Prof. R.M. Phuke, Prof. P.M. Raut, Prof. G.R. Bharsakle, Prof. D.A. Zamre इतर.',

NULL);

-- ============================================================
-- DEPARTMENTS - MECHANICAL
-- ============================================================
INSERT INTO chatbot (keyword, category, reply, reply_hindi, reply_marathi, image) VALUES
('mechanical', 'departments',
'<b>⚙️ Mechanical Engineering Department</b><br>
<b>Seats:</b> 60 | <b>Duration:</b> 4 Years<br><br>
<b>Faculty:</b><br>
• Dr. S.C. Makwana – Head & Associate Professor<br>
• Dr. P.S. Ardak – Associate Professor<br>
• Prof. S.P. Dhomane – Assistant Professor<br>
• Prof. S.R. Alase – Assistant Professor<br>
• Prof. S.R. Thakare – Assistant Professor<br>
• Prof. M.R. Pundkar – Assistant Professor<br>
• Prof. A.S. Tolmare – Assistant Professor<br>
• Prof. C.V. Bahagt – Assistant Professor',

'<b>⚙️ मैकेनिकल इंजीनियरिंग विभाग</b><br>
<b>सीटें:</b> 60 | <b>HOD:</b> Dr. S.C. Makwana<br>
<b>फैकल्टी:</b> Dr. P.S. Ardak, Prof. S.P. Dhomane, Prof. S.R. Alase, Prof. S.R. Thakare, Prof. M.R. Pundkar, Prof. A.S. Tolmare, Prof. C.V. Bahagt',

'<b>⚙️ यांत्रिकी अभियांत्रिकी विभाग</b><br>
<b>जागा:</b> 60 | <b>HOD:</b> Dr. S.C. Makwana<br>
<b>प्राध्यापक:</b> Dr. P.S. Ardak, Prof. S.P. Dhomane, Prof. S.R. Alase, Prof. S.R. Thakare, Prof. M.R. Pundkar इतर.',

NULL);

-- ============================================================
-- DEPARTMENTS - CHEMICAL
-- ============================================================
INSERT INTO chatbot (keyword, category, reply, reply_hindi, reply_marathi, image) VALUES
('chemical', 'departments',
'<b>🧪 Chemical Engineering Department</b><br>
<b>Seats:</b> 60 | <b>Duration:</b> 4 Years<br><br>
<b>Faculty:</b><br>
• Dr. P.V. Thorat – Principal & Professor<br>
• Dr. Gopal S. Zamre – Head & Associate Professor<br>
• Dr. D.V. Wele – Associate Professor<br>
• Dr. M.S. Patil – Associate Professor<br>
• Dr. S.V. Khedkar – Associate Professor<br>
• Dr. A.P. Gawande – Assistant Professor<br>
• Prof. R.S. Jadhao – Assistant Professor<br>
• Prof. M.A. Badole – Assistant Professor<br>
• Prof. N.P. Sirse – Assistant Professor',

'<b>🧪 केमिकल इंजीनियरिंग विभाग</b><br>
<b>सीटें:</b> 60 | <b>HOD:</b> Dr. Gopal S. Zamre<br>
<b>फैकल्टी:</b> Dr. D.V. Wele, Dr. M.S. Patil, Dr. S.V. Khedkar, Dr. A.P. Gawande, Prof. R.S. Jadhao, Prof. M.A. Badole, Prof. N.P. Sirse',

'<b>🧪 रासायनिक अभियांत्रिकी विभाग</b><br>
<b>जागा:</b> 60 | <b>HOD:</b> Dr. Gopal S. Zamre<br>
<b>प्राध्यापक:</b> Dr. D.V. Wele, Dr. M.S. Patil, Dr. S.V. Khedkar, Dr. A.P. Gawande इतर.',

NULL);

-- ============================================================
-- DEPARTMENTS - MBA
-- ============================================================
INSERT INTO chatbot (keyword, category, reply, reply_hindi, reply_marathi, image) VALUES
('mba', 'departments',
'<b>💼 MBA Department</b><br>
<b>Seats:</b> 60 | <b>Duration:</b> 2 Years<br><br>
<b>Faculty:</b><br>
• Prof. S.R. Sonkhaskar – HOD<br>
• Prof. A.N. Tayade – Assistant Professor<br>
• Prof. V.R. Kokatay – Assistant Professor<br>
• Prof. K.P. Shingote – Assistant Professor',

'<b>💼 MBA विभाग</b><br>
<b>सीटें:</b> 60 | <b>HOD:</b> Prof. S.R. Sonkhaskar<br>
<b>फैकल्टी:</b> Prof. A.N. Tayade, Prof. V.R. Kokatay, Prof. K.P. Shingote',

'<b>💼 MBA विभाग</b><br>
<b>जागा:</b> 60 | <b>HOD:</b> Prof. S.R. Sonkhaskar<br>
<b>प्राध्यापक:</b> Prof. A.N. Tayade, Prof. V.R. Kokatay, Prof. K.P. Shingote',

NULL);

-- ============================================================
-- DEPARTMENTS - ME CSE (FYMC)
-- ============================================================
INSERT INTO chatbot (keyword, category, reply, reply_hindi, reply_marathi, image) VALUES
('me cse', 'departments',
'<b>🖥️ M.E. Computer Science & Engineering</b><br>
<b>Seats:</b> 18 | <b>Duration:</b> 2 Years<br>
<b>FYMC Chairman & HOD:</b> Dr. P.S. Ardak – Associate Professor<br><br>
<b>Faculty:</b><br>
• Dr. P.D. Bhanavat – Assistant Professor<br>
• Dr. J.V. Shegokar – Assistant Professor<br>
• Dr. D.D. Raut – Assistant Professor<br>
• Prof. S.J. Ningwal – Assistant Professor<br>
• Prof. S.D. Deshmukh – Assistant Professor<br>
• Prof. A.A. Bihade – Assistant Professor<br>
• Prof. R.U. Pote – Assistant Professor<br>
• Prof. K.V. Nile – Assistant Professor<br>
• Prof. S.S. Kale – Assistant Professor<br>
• Prof. R.D. Bhire – Assistant Professor<br>
• Prof. A.S. Gawande<br>
• Prof. A.S. Vidhale<br>
• Prof. S.B. Sonawane',

'<b>🖥️ M.E. कंप्यूटर साइंस</b><br>
<b>सीटें:</b> 18 | <b>HOD:</b> Dr. P.S. Ardak<br>
<b>फैकल्टी:</b> Dr. P.D. Bhanavat, Dr. J.V. Shegokar, Dr. D.D. Raut, Prof. S.J. Ningwal, Prof. S.D. Deshmukh, Prof. A.A. Bihade, Prof. R.U. Pote, Prof. K.V. Nile, Prof. S.S. Kale, Prof. A.S. Gawande इतर।',

'<b>🖥️ M.E. संगणक विज्ञान</b><br>
<b>जागा:</b> 18 | <b>HOD:</b> Dr. P.S. Ardak<br>
<b>प्राध्यापक:</b> Dr. P.D. Bhanavat, Dr. J.V. Shegokar, Dr. D.D. Raut, Prof. S.J. Ningwal इतर.',

NULL);

-- ============================================================
-- FEES
-- ============================================================
INSERT INTO chatbot (keyword, category, reply, reply_hindi, reply_marathi, image) VALUES
('fee', 'fees',
'<b>💰 Fee Structure 2025-2026 - COET Akola</b><br><br>
<b>U.G. Courses (B.E. / B.Tech / B.Arch):</b><br>
<table style="border-collapse:collapse;width:100%;font-size:12px;">
<tr style="background:#1e88e5;color:white;">
<td style="padding:4px 6px;"><b>Course</b></td>
<td style="padding:4px 6px;"><b>Open/CAP</b></td>
<td style="padding:4px 6px;"><b>OBC/EBC</b></td>
<td style="padding:4px 6px;"><b>VJ/NT/TFWS</b></td>
<td style="padding:4px 6px;"><b>SC/ST</b></td>
</tr>
<tr><td style="padding:3px 6px;">B.E. First Year</td><td>₹1,20,531</td><td>₹69,439</td><td>₹18,347</td><td>₹3,531</td></tr>
<tr style="background:#f0f4ff;"><td style="padding:3px 6px;">B.Arch First Year</td><td>₹1,19,264</td><td>₹67,937</td><td>₹16,609</td><td>₹3,264</td></tr>
<tr><td style="padding:3px 6px;">B.E. Direct 2nd Year</td><td>₹1,09,284</td><td>₹62,574</td><td>₹15,864</td><td>₹2,784</td></tr>
<tr style="background:#f0f4ff;"><td style="padding:3px 6px;">MBA</td><td>₹1,01,864</td><td>₹56,410</td><td>₹10,955</td><td>₹1,864</td></tr>
<tr><td style="padding:3px 6px;">M.E./M.Tech</td><td>₹1,00,444</td><td>₹1,00,444</td><td>₹1,00,444</td><td>₹2,444</td></tr>
<tr style="background:#f0f4ff;"><td style="padding:3px 6px;">D.Arch (Diploma)</td><td>₹47,454</td><td>₹27,000</td><td>₹6,545</td><td>₹2,454</td></tr>
</table><br>
<b>Note:</b> Fees as per FRA, FFC, SGBAU & MSBTE. Subject to change.<br>
<b>Scholarships:</b> Available for SC/ST, OBC, EWS & Girls (TFWS)',

'<b>💰 शुल्क संरचना 2025-2026</b><br>
• बी.ई. प्रथम वर्ष (Open): ₹1,20,531 | OBC: ₹69,439 | SC/ST: ₹3,531<br>
• बी.आर्क (Open): ₹1,19,264 | OBC: ₹67,937<br>
• बी.ई. द्वितीय वर्ष (Open): ₹1,09,284<br>
• MBA (Open): ₹1,01,864 | OBC: ₹56,410<br>
• M.E./M.Tech: ₹1,00,444 | SC only: ₹2,444<br>
• D.Arch डिप्लोमा (Open): ₹47,454<br>
<b>छात्रवृत्ति:</b> SC/ST, OBC, EWS एवं Girls TFWS के लिए उपलब्ध',

'<b>💰 शुल्क रचना 2025-2026</b><br>
• बी.ई. प्रथम वर्ष (Open): ₹1,20,531 | OBC: ₹69,439 | SC/ST: ₹3,531<br>
• बी.आर्क (Open): ₹1,19,264<br>
• MBA (Open): ₹1,01,864<br>
• M.E./M.Tech: ₹1,00,444<br>
• D.Arch (Open): ₹47,454<br>
<b>शिष्यवृत्ती:</b> SC/ST, OBC, EWS व मुलींसाठी उपलब्ध',

NULL);

-- ============================================================
-- HOSTEL
-- ============================================================
INSERT INTO chatbot (keyword, category, reply, reply_hindi, reply_marathi, image) VALUES
('hostel', 'hostel',
'<b>🏠 Hostel Facility - COET Akola</b><br><br>
<b>Girls Hostel:</b> Available on campus<br>
<b>Room Sharing:</b> 4 girls per room<br><br>
<b>Facilities:</b><br>
• 24x7 Water Supply<br>
• Wi-Fi Facility<br>
• Mess Facility (Hygienic food)<br>
• Study Room<br>
• Common Washroom<br>
• Clean and Hygienic Environment<br>
• CCTV Surveillance<br>
• Warden available 24/7<br><br>
<b>Rules:</b><br>
• Back by 8:30 PM mandatory<br>
• Parents visiting hours: 6:00 PM – 8:00 PM<br>
• Zero tolerance to ragging<br><br>
<b>Annual Hostel Fee:</b> ₹24,000 (Approx.)<br>
<b>Location:</b> Babhulgaon (Jh) N.H. No. 6, Akola – 444 104',

'<b>🏠 छात्रावास सुविधा - COET अकोला</b><br>
<b>गर्ल्स हॉस्टल:</b> कैंपस में उपलब्ध<br>
<b>कमरा:</b> 4 लड़कियां प्रति कमरा<br>
<b>सुविधाएं:</b><br>
• 24x7 पानी की आपूर्ति<br>
• Wi-Fi सुविधा<br>
• मेस (स्वच्छ भोजन)<br>
• अध्ययन कक्ष<br>
• CCTV निगरानी<br>
• वार्डन 24/7 उपलब्ध<br>
<b>नियम:</b> रात 8:30 बजे तक वापस आना अनिवार्य<br>
<b>वार्षिक शुल्क:</b> ₹24,000 (लगभग)',

'<b>🏠 वसतिगृह सुविधा - COET अकोला</b><br>
<b>मुलींचे वसतिगृह:</b> कॅम्पसमध्ये उपलब्ध<br>
<b>खोली:</b> 4 मुली प्रति खोली<br>
<b>सुविधा:</b><br>
• 24x7 पाण्याचा पुरवठा<br>
• Wi-Fi सुविधा<br>
• मेस (स्वच्छ जेवण)<br>
• अभ्यास कक्ष<br>
• CCTV देखरेख<br>
<b>नियम:</b> रात्री 8:30 पर्यंत परतणे बंधनकारक<br>
<b>वार्षिक शुल्क:</b> ₹24,000 (अंदाजे)',

'hostel_front.jpeg,hostel_building.jpeg,hostel_side.jpeg,hostel_corridor.jpeg,hostel_mess.jpeg');

-- ============================================================
-- LIBRARY
-- ============================================================
INSERT INTO chatbot (keyword, category, reply, reply_hindi, reply_marathi, image) VALUES
('library', 'library',
'<b>📖 Central Library - COET Akola</b><br><br>
<b>Library Timing:</b> 9:00 AM – 5:00 PM (Mon-Sat)<br><br>
<b>Books Collection (Course-wise):</b><br>
• Mechanical Engineering: 2417 titles, 7921 volumes<br>
• Chemical Engineering: 1629 titles, 6897 volumes<br>
• Civil Engineering: 1911 titles, 6268 volumes<br>
• Computer Science & Engg: 1267 titles, 7723 volumes<br>
• B. Architecture: 2200 titles, 3441 volumes<br>
• Science & Humanities: 3199 titles, 8264 volumes<br>
• Bound Volumes: 19,08,246<br><br>
<b>Total: 12,623 titles | 40,514 volumes</b><br>
<b>Total Cost:</b> ₹1,95,25,292<br><br>
<b>Facilities:</b> Reading hall, Reference section, Digital catalogue',

'<b>📖 केंद्रीय पुस्तकालय - COET अकोला</b><br>
<b>समय:</b> सुबह 9 बजे – शाम 5 बजे (सोम-शनि)<br>
<b>पुस्तकें:</b><br>
• मैकेनिकल: 2417 शीर्षक, 7921 खंड<br>
• केमिकल: 1629 शीर्षक, 6897 खंड<br>
• सिविल: 1911 शीर्षक, 6268 खंड<br>
• CSE: 1267 शीर्षक, 7723 खंड<br>
• आर्किटेक्चर: 2200 शीर्षक, 3441 खंड<br>
• विज्ञान & मानविकी: 3199 शीर्षक, 8264 खंड<br>
<b>कुल: 12,623 शीर्षक | 40,514 खंड</b>',

'<b>📖 मध्यवर्ती ग्रंथालय - COET अकोला</b><br>
<b>वेळ:</b> सकाळी 9 – सायंकाळी 5 (सोम-शनि)<br>
<b>पुस्तके:</b><br>
• यांत्रिकी: 2417 शीर्षक, 7921 खंड<br>
• रासायनिक: 1629 शीर्षक, 6897 खंड<br>
• स्थापत्य: 1911 शीर्षक, 6268 खंड<br>
• CSE: 1267 शीर्षक, 7723 खंड<br>
<b>एकूण: 12,623 शीर्षक | 40,514 खंड</b>',

'library1.jpeg,library2.jpeg');

-- ============================================================
-- CANTEEN
-- ============================================================
INSERT INTO chatbot (keyword, category, reply, reply_hindi, reply_marathi, image) VALUES
('canteen', 'canteen',
'<b>🍽️ Canteen - COET Akola</b><br><br>
<b>Canteen is available on campus!</b><br><br>
<b>Facilities:</b><br>
• Spacious & clean dining area<br>
• Hygienic food at affordable prices<br>
• Comfortable seating arrangement<br>
• Available for all students & staff<br><br>
<b>Note:</b> More details about menu & timing will be updated soon.<br>
<b>Location:</b> Inside campus premises',

'<b>🍽️ कैंटीन - COET अकोला</b><br>
<b>कैंटीन कैंपस में उपलब्ध है!</b><br>
<b>सुविधाएं:</b><br>
• स्वच्छ और विशाल भोजन क्षेत्र<br>
• किफायती कीमतों पर स्वच्छ भोजन<br>
• सभी छात्रों और स्टाफ के लिए उपलब्ध',

'<b>🍽️ कॅन्टीन - COET अकोला</b><br>
<b>कॅन्टीन कॅम्पसमध्ये उपलब्ध आहे!</b><br>
<b>सुविधा:</b><br>
• स्वच्छ व प्रशस्त जेवण क्षेत्र<br>
• परवडणाऱ्या किमतीत स्वच्छ जेवण<br>
• सर्व विद्यार्थी व कर्मचाऱ्यांसाठी उपलब्ध',

'canteen1.jpeg');

-- ============================================================
-- PLACEMENT
-- ============================================================
INSERT INTO chatbot (keyword, category, reply, reply_hindi, reply_marathi, image) VALUES
('placement', 'placement',
'<b>💼 Placement Cell - COET Akola</b><br><br>
<b>Head of Placement Cell:</b> Dr. Agrawal Sir<br>
<b>Internship Head:</b> Prof. K. Barabde Mam<br><br>
<b>Placement Statistics:</b><br>
• Total Placements: 350+<br>
• Students Placed Per Year: ~53<br>
• B.Tech/B.Arch Average Package: ₹2-3 LPA<br><br>
<b>Top Recruiters:</b><br>
• TCS<br>
• Wipro<br>
• Capgemini<br>
• And many more...<br><br>
<b>Training:</b> Aptitude, Technical & Soft Skills training provided<br>
<b>Internship:</b> Regular internship opportunities available',

'<b>💼 प्लेसमेंट सेल - COET अकोला</b><br>
<b>प्लेसमेंट प्रमुख:</b> Dr. Agrawal Sir<br>
<b>इंटर्नशिप प्रमुख:</b> Prof. K. Barabde Mam<br>
<b>कुल प्लेसमेंट:</b> 350+<br>
<b>प्रति वर्ष:</b> ~53 छात्र<br>
<b>औसत पैकेज:</b> ₹2-3 LPA (B.Tech/B.Arch)<br>
<b>शीर्ष कंपनियां:</b> TCS, Wipro, Capgemini',

'<b>💼 प्लेसमेंट सेल - COET अकोला</b><br>
<b>प्लेसमेंट प्रमुख:</b> Dr. Agrawal Sir<br>
<b>इंटर्नशिप प्रमुख:</b> Prof. K. Barabde Mam<br>
<b>एकूण प्लेसमेंट:</b> 350+<br>
<b>प्रति वर्ष:</b> ~53 विद्यार्थी<br>
<b>सरासरी पॅकेज:</b> ₹2-3 LPA (B.Tech/B.Arch)<br>
<b>शीर्ष कंपन्या:</b> TCS, Wipro, Capgemini',

NULL);

-- ============================================================
-- TRANSPORT
-- ============================================================
INSERT INTO chatbot (keyword, category, reply, reply_hindi, reply_marathi, image) VALUES
('transport', 'transport',
'<b>🚌 Transport Facility - COET Akola</b><br><br>
<b>College Buses Available!</b><br>
College of Engineering and Technology, Akola provides bus facility for students.<br><br>
<b>Features:</b><br>
• Multiple college buses available<br>
• Covers various routes in and around Akola<br>
• Safe and reliable transport<br><br>
<b>For Route & Timing Details:</b><br>
Contact the college office or transport in-charge.<br>
<b>Phone:</b> 9960590202',

'<b>🚌 परिवहन सुविधा - COET अकोला</b><br>
<b>कॉलेज बस उपलब्ध!</b><br>
अकोला और आसपास के क्षेत्रों के लिए बस सुविधा उपलब्ध है।<br>
<b>रूट और समय के लिए:</b> कॉलेज कार्यालय से संपर्क करें।<br>
<b>फोन:</b> 9960590202',

'<b>🚌 वाहतूक सुविधा - COET अकोला</b><br>
<b>महाविद्यालय बस उपलब्ध!</b><br>
अकोला व परिसरातील विद्यार्थ्यांसाठी बस सुविधा उपलब्ध आहे.<br>
<b>मार्ग व वेळासाठी:</b> महाविद्यालय कार्यालयाशी संपर्क करा.<br>
<b>फोन:</b> 9960590202',

'bus1.jpeg');

-- ============================================================
-- CONTACT
-- ============================================================
INSERT INTO chatbot (keyword, category, reply, reply_hindi, reply_marathi, image) VALUES
('contact', 'contact',
'<b>📞 Contact - COET Akola</b><br><br>
<b>College of Engineering and Technology, Akola</b><br>
Shri Shivaji Education Society, Amravati<br>
Babhulgaon (Jh) N.H. No. 6, Akola – 444 104<br><br>
<b>Principal:</b> Dr. P.V. Thorat<br>
📞 9960590202<br><br>
<b>Affiliated to:</b> Sant Gadge Baba Amravati University<br>
<b>Approved by:</b> AICTE<br>
<b>NAAC:</b> Accredited with Grade "A"<br><br>
<b>Office Hours:</b> Mon-Sat, 9:00 AM – 5:00 PM',

'<b>📞 संपर्क - COET अकोला</b><br>
<b>कॉलेज ऑफ इंजीनियरिंग एंड टेक्नोलॉजी, अकोला</b><br>
श्री शिवाजी शिक्षण संस्था, अमरावती<br>
बाभुळगाव (झ) NH No. 6, अकोला – 444 104<br>
<b>प्राचार्य:</b> Dr. P.V. Thorat | 📞 9960590202<br>
<b>कार्यालय समय:</b> सोम-शनि, सुबह 9 – शाम 5',

'<b>📞 संपर्क - COET अकोला</b><br>
<b>कॉलेज ऑफ इंजिनिअरिंग अँड टेक्नॉलॉजी, अकोला</b><br>
श्री शिवाजी शिक्षण संस्था, अमरावती<br>
बाभूळगाव (झ) NH No. 6, अकोला – 444 104<br>
<b>प्राचार्य:</b> Dr. P.V. Thorat | 📞 9960590202<br>
<b>कार्यालय वेळ:</b> सोम-शनि, सकाळी 9 – सायंकाळी 5',

NULL);

-- ============================================================
-- LOCATION / CAMPUS MAP
-- ============================================================
INSERT INTO chatbot (keyword, category, reply, reply_hindi, reply_marathi, image) VALUES
('location', 'location',
'<b>📍 Campus Location - COET Akola</b><br><br>
<b>Address:</b><br>
College of Engineering and Technology,<br>
Babhulgaon (Jh) N.H. No. 6, Akola – 444 104<br><br>
<b>Campus Facilities Location:</b><br>
🏛️ Main Building – Administrative Office, Principal Office<br>
🖥️ CSE & IT Department – Main Academic Block<br>
🏗️ Civil & Mechanical Department – Engineering Block<br>
🧪 Chemical Department – Lab Block<br>
🏠 Girls Hostel – Inside Campus (Separate Block)<br>
📖 Library – Ground Floor, Main Building<br>
🍽️ Canteen – Campus Premises<br>
🚌 Bus Stand – College Gate<br>
🏟️ Playground – Open Ground Area<br><br>
<b>How to Reach:</b><br>
• Located on NH No. 6, Babhulgaon<br>
• Near Akola City<br>
<b>Google Maps:</b> Search "COET Akola" or "College of Engineering and Technology Akola"',

'<b>📍 कैंपस लोकेशन - COET अकोला</b><br>
<b>पता:</b> बाभुळगाव (झ) NH No. 6, अकोला – 444 104<br>
<b>कैंपस में:</b><br>
🏛️ मुख्य भवन – प्रशासनिक कार्यालय<br>
🏠 गर्ल्स हॉस्टल – अलग ब्लॉक<br>
📖 पुस्तकालय – मुख्य भवन तल मंजिल<br>
🍽️ कैंटीन – कैंपस परिसर<br>
🚌 बस स्टैंड – कॉलेज गेट<br>
<b>Google Maps:</b> "COET Akola" सर्च करें',

'<b>📍 कॅम्पस स्थान - COET अकोला</b><br>
<b>पत्ता:</b> बाभूळगाव (झ) NH No. 6, अकोला – 444 104<br>
<b>कॅम्पसमध्ये:</b><br>
🏛️ मुख्य इमारत – प्रशासकीय कार्यालय<br>
🏠 मुलींचे वसतिगृह – स्वतंत्र ब्लॉक<br>
📖 ग्रंथालय – मुख्य इमारत तळमजला<br>
🍽️ कॅन्टीन – कॅम्पस परिसर<br>
🚌 बस स्टँड – महाविद्यालय दरवाजा<br>
<b>Google Maps:</b> "COET Akola" शोधा',

NULL);

-- ============================================================
-- ADMISSION
-- ============================================================
INSERT INTO chatbot (keyword, category, reply, reply_hindi, reply_marathi, image) VALUES
('admission', 'admission',
'<b>📋 Admission - COET Akola</b><br><br>
<b>Eligibility:</b><br>
• B.E./B.Tech: 12th PCM with min. 45% (40% for reserved)<br>
• B.Arch: 12th with Maths + NATA score<br>
• MBA: Graduation with 50% marks<br>
• M.E./M.Tech: B.E./B.Tech with 50% marks<br>
• Diploma (D.Arch): 10th pass<br><br>
<b>Entrance Exams Required:</b><br>
• B.E.: MHT-CET / JEE Mains<br>
• B.Arch: MHT-CET / NATA<br>
• MBA: MAT / CAT / MH-CET<br><br>
<b>Documents Required:</b><br>
10th & 12th Marksheet, Leaving Certificate, Aadhar Card, Passport Size Photo (6), Caste Certificate (if applicable)<br><br>
<b>Contact:</b> 9960590202<br>
<b>Office:</b> Mon-Sat, 9:00 AM – 5:00 PM',

'<b>📋 प्रवेश प्रक्रिया - COET अकोला</b><br>
<b>पात्रता:</b><br>
• बी.ई.: 12वीं PCM 45% | MBA: स्नातक 50%<br>
<b>प्रवेश परीक्षा:</b> MHT-CET / JEE (B.E.) | MAT/CAT (MBA)<br>
<b>दस्तावेज:</b> 10वीं/12वीं मार्कशीट, LC, आधार, फोटो<br>
<b>संपर्क:</b> 9960590202',

'<b>📋 प्रवेश प्रक्रिया - COET अकोला</b><br>
<b>पात्रता:</b><br>
• बी.ई.: 12वी PCM 45% | MBA: पदवी 50%<br>
<b>प्रवेश परीक्षा:</b> MHT-CET / JEE (B.E.) | MAT/CAT (MBA)<br>
<b>कागदपत्रे:</b> 10वी/12वी गुणपत्रिका, LC, आधार, फोटो<br>
<b>संपर्क:</b> 9960590202',

NULL);

-- ============================================================
-- GREET
-- ============================================================
INSERT INTO chatbot (keyword, category, reply, reply_hindi, reply_marathi, image) VALUES
('hello', 'greet',
'👋 Hello! Welcome to <b>COET Akola Chatbot</b>!<br>
College of Engineering and Technology, Akola<br>
(Shri Shivaji Education Society, Amravati)<br><br>
I can help you with:<br>
🎓 Principal | 📚 Courses | 💰 Fees | 🏠 Hostel<br>
📖 Library | 🍽️ Canteen | 💼 Placement | 📋 Admission<br>
📞 Contact | 📍 Location | 🚌 Transport | 🏗️ Departments<br><br>
Type your question in English, Hindi or Marathi!',

'👋 नमस्ते! <b>COET अकोला चैटबॉट</b> में आपका स्वागत है!<br>
मैं आपकी मदद कर सकता हूँ: प्राचार्य, कोर्स, शुल्क, छात्रावास, पुस्तकालय, कैंटीन, प्लेसमेंट, प्रवेश, संपर्क के बारे में।<br>
अंग्रेजी, हिंदी या मराठी में पूछें!',

'👋 नमस्कार! <b>COET अकोला चॅटबॉट</b>मध्ये आपले स्वागत!<br>
मी मदत करू शकतो: प्राचार्य, अभ्यासक्रम, शुल्क, वसतिगृह, ग्रंथालय, कॅन्टीन, प्लेसमेंट, प्रवेश, संपर्क.<br>
इंग्रजी, हिंदी किंवा मराठीत विचारा!',

NULL);

INSERT INTO chatbot (keyword, category, reply, reply_hindi, reply_marathi, image) VALUES
('hi', 'greet',
'👋 Hi! Welcome to <b>COET Akola Bot</b>!<br>Ask me about courses, fees, hostel, placement, admission or any college info!',
'👋 नमस्ते! COET अकोला बॉट में आपका स्वागत! कोई भी जानकारी पूछें।',
'👋 नमस्कार! COET अकोला बॉटमध्ये स्वागत! कोणतीही माहिती विचारा.',
NULL);

-- Hindi keywords
INSERT INTO chatbot (keyword, category, reply, reply_hindi, reply_marathi, image) VALUES
('नमस्ते', 'greet',
'👋 Hello! Welcome to COET Akola Chatbot! Ask me anything about the college.',
'👋 नमस्ते! COET अकोला चैटबॉट में स्वागत है! कॉलेज के बारे में कुछ भी पूछें।',
'👋 नमस्कार! COET अकोला चॅटबॉटमध्ये स्वागत! महाविद्यालयाबद्दल काहीही विचारा.',
NULL);

INSERT INTO chatbot (keyword, category, reply, reply_hindi, reply_marathi, image) VALUES
('प्राचार्य', 'principal',
'<b>🎓 Principal - Dr. P.V. Thorat</b><br>Ph.D. Chemical Engineering, M.Tech<br>Phone: 9960590202',
'<b>🎓 प्राचार्य - डॉ. पी.व्ही. थोरात</b><br>पीएच.डी. रासायनिक अभियांत्रिकी, एम.टेक<br>फोन: 9960590202',
'<b>🎓 प्राचार्य - डॉ. पी.व्ही. थोरात</b><br>पीएच.डी. रासायनिक अभियांत्रिकी, एम.टेक<br>फोन: 9960590202',
'principle.jpeg');

INSERT INTO chatbot (keyword, category, reply, reply_hindi, reply_marathi, image) VALUES
('छात्रावास', 'hostel',
'<b>🏠 Girls Hostel - COET Akola</b><br>4 girls per room | 24x7 Water | WiFi | Mess | Study Room<br>Annual Fee: ₹24,000 (Approx.)',
'<b>🏠 गर्ल्स हॉस्टल</b><br>4 लड़कियां/कमरा | 24x7 पानी | WiFi | मेस | अध्ययन कक्ष<br>वार्षिक शुल्क: ₹24,000 (लगभग)',
'<b>🏠 मुलींचे वसतिगृह</b><br>4 मुली/खोली | 24x7 पाणी | WiFi | मेस | अभ्यास कक्ष<br>वार्षिक शुल्क: ₹24,000 (अंदाजे)',
'hostel_front.jpeg,hostel_building.jpeg,hostel_side.jpeg');

INSERT INTO chatbot (keyword, category, reply, reply_hindi, reply_marathi, image) VALUES
('वसतिगृह', 'hostel',
'<b>🏠 Girls Hostel - COET Akola</b><br>4 girls per room | 24x7 Water | WiFi | Mess | Study Room<br>Annual Fee: ₹24,000 (Approx.)',
'<b>🏠 गर्ल्स हॉस्टल</b><br>4 लड़कियां/कमरा | 24x7 पानी | WiFi | मेस<br>वार्षिक शुल्क: ₹24,000',
'<b>🏠 मुलींचे वसतिगृह</b><br>4 मुली/खोली | 24x7 पाणी | WiFi | मेस<br>वार्षिक शुल्क: ₹24,000 (अंदाजे)',
'hostel_front.jpeg,hostel_building.jpeg,hostel_side.jpeg');

INSERT INTO chatbot (keyword, category, reply, reply_hindi, reply_marathi, image) VALUES
('प्रवेश', 'admission',
'<b>📋 Admission - COET Akola</b><br>B.E.: 12th PCM 45% | MBA: Graduation 50%<br>Entrance: MHT-CET/JEE | Contact: 9960590202',
'<b>📋 प्रवेश - COET अकोला</b><br>बी.ई.: 12वीं PCM 45% | MBA: स्नातक 50%<br>प्रवेश परीक्षा: MHT-CET/JEE | संपर्क: 9960590202',
'<b>📋 प्रवेश - COET अकोला</b><br>बी.ई.: 12वी PCM 45% | MBA: पदवी 50%<br>प्रवेश परीक्षा: MHT-CET/JEE | संपर्क: 9960590202',
NULL);

-- ============================================================
SELECT COUNT(*) AS total_keywords FROM chatbot;
